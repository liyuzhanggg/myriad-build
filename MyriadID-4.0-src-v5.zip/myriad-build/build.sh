#!/bin/sh
# 用官方 NDK 交叉编译 libmyriad.so（CI 或本地均可）
set -e
NDK="${ANDROID_NDK:-$ANDROID_NDK_ROOT}"
API=24
CXX="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/clang++"
[ -x "$CXX" ] || { echo "找不到 NDK clang++: $CXX"; exit 1; }
$CXX --target=aarch64-linux-android$API -std=c++20 -Oz -fPIC -fno-exceptions -fno-rtti \
  -Isrc -shared -o libmyriad.so src/v4.cpp \
  -static-libstdc++ -llog -ldl
echo "产物: $(ls -la libmyriad.so)"
