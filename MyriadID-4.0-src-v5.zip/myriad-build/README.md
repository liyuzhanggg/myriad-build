# MyriadID 4.0 构建（GitHub Actions）

用官方 NDK 编译 `libmyriad.so`，产物用于 ptrace 注入 Widevine HAL。

## 手机上的操作步骤

1. 在 GitHub 新建一个仓库（Public 即可，免费且不限时长）
2. 把这个文件夹里的所有文件上传（网页上「Add file → Upload files」可直接拖入）
   - `src/v4.cpp`、`src/elfio/`、`build.sh`、`.github/workflows/build.yml`
3. 打开仓库的 **Actions** 标签 → 左侧 `build` → 右侧 **Run workflow**
4. 等 2~3 分钟，构建完成后进入该次运行，页面底部 **Artifacts** 下载 `libmyriad.zip`
5. 解压得到 `libmyriad.so`，传到手机即可

## 本地构建（有 Linux 时）

```sh
export ANDROID_NDK=/path/to/ndk
sh build.sh          # 产出 libmyriad.so
```

## 产物怎么用

```
cp libmyriad.so /data/local/tmp/
chmod 755 /data/local/tmp/libmyriad.so
chcon u:object_r:shell_data_file:s0 /data/local/tmp/libmyriad.so
# 用 TencDRM 的注入器注入（已验证可用）
/data/local/tmp/tdinject <widevine_hal_pid> /data/local/tmp/libmyriad.so <符号>
```

> 说明：`v4.cpp` 里 `myriad_init()` 是显式入口（不依赖构造函数），
> 定位 `libwvaidl` 后自研 inline hook，改 `getPropertyByteArray("deviceUniqueId")` 的返回值。
