// 千面 MyriadID · parcel 层伪装（参考 TencDRM 的公开实现思路）
#include <android/log.h>
#include <sys/system_properties.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <dlfcn.h>
#include <link.h>
#include <cstring>
#include <cstdint>
#include <cstdio>
#include <cerrno>
#include <csignal>
#include <csetjmp>
#include <unistd.h>
#include <string>
#include <vector>

#define TAG "MyriadV5"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

typedef int32_t binder_status_t;
typedef int32_t AParcel;
typedef binder_status_t (*writeBA_t)(AParcel*, const uint8_t*, int32_t);
typedef binder_status_t (*readStr_t)(const AParcel*, char**, int32_t*);

static writeBA_t g_orig_writeBA = nullptr;
static readStr_t g_orig_readStr = nullptr;

static unsigned char g_seed[64]; static size_t g_seed_len = 0;
static bool g_on = true; static bool g_ready = false;
static sigjmp_buf g_jmp;
static volatile int g_in_arm = 0;
static void segv_handler(int sig) { if (g_in_arm) { g_in_arm = 0; siglongjmp(g_jmp, sig); } }
static char g_lastKey[64] = {0};

static int hexv(char c){ if(c>='0'&&c<='9')return c-'0'; if(c>='a'&&c<='f')return c-'a'+10; if(c>='A'&&c<='F')return c-'A'+10; return 0; }
static void load_cfg(void) {
    char b[PROP_VALUE_MAX];
    g_seed_len = 0;
    if (__system_property_get("vendor.myriad.seed", b) > 0) {
        int n = (int)strlen(b); if (n > 128) n = 128;
        for (int i = 0; i + 1 < n && g_seed_len < 64; i += 2) g_seed[g_seed_len++] = (unsigned char)((hexv(b[i])<<4)|hexv(b[i+1]));
    }
    if (__system_property_get("vendor.myriad.enable", b) > 0 && b[0] == '0') g_on = false;
}
static void derive(uint32_t uid, unsigned char *out, size_t n) {
    uint32_t h = 2166136261u;
    for (size_t i = 0; i < g_seed_len; i++) { h ^= g_seed[i]; h *= 16777619u; }
    for (int i = 0; i < 4; i++) { h ^= (uid >> (8*i)) & 0xFFu; h *= 16777619u; }
    if (!h) h = 0x9E3779B9u;
    for (size_t i = 0; i < n; i++) { h ^= h << 13; h ^= h >> 17; h ^= h << 5; out[i] = (unsigned char)(h & 0xFF); }
}

// ---- 挂钩：AParcel_readString 记录属性名；writeByteArray 替换 32 字节 ID ----
static binder_status_t hook_readStr(const AParcel *p, char **str, int32_t *len) {
    binder_status_t r = g_orig_readStr ? g_orig_readStr(p, str, len) : -1;
    if (str && *str) {
        size_t n = strlen(*str);
        if (n < sizeof(g_lastKey)) { memcpy(g_lastKey, *str, n); g_lastKey[n] = 0; }
    }
    return r;
}
static binder_status_t hook_writeBA(AParcel *p, const uint8_t *buf, int32_t len) {
    if (len == 32 && buf && g_on && g_seed_len > 0 &&
        (strcmp(g_lastKey, "deviceUniqueId") == 0 || g_lastKey[0] == 0)) {
        unsigned char tmp[32];
        derive((uint32_t)getuid(), tmp, sizeof(tmp));
        LOGI("spoof parcel: key=[%s] uid=%u", g_lastKey, (unsigned)getuid());
        return g_orig_writeBA ? g_orig_writeBA(p, tmp, len) : -1;
    }
    return g_orig_writeBA ? g_orig_writeBA(p, buf, len) : -1;
}


// ---- inline hook（复用已验证实现）----
extern "C" __attribute__((visibility("hidden"))) void *g_orig_w = nullptr;
extern "C" __attribute__((visibility("hidden"))) void *g_orig_r = nullptr;
extern "C" void shim_w(void);
extern "C" void shim_r(void);
extern "C" void callw(void*, const void*, long);
extern "C" void callr(void const*, void*, void*);

__asm__(
".text\n"
".global shim_w\n"
".type shim_w, %function\n"
"shim_w:\n"
"  stp x29, x30, [sp, #-16]!\n"
"  mov x29, sp\n"
"  bl hook_writeBA_impl\n"
"  ldp x29, x30, [sp], #16\n"
"  ret\n"
".global callw\n"
".type callw, %function\n"
"callw:\n"
"  stp x29, x30, [sp, #-16]!\n"
"  mov x29, sp\n"
"  adrp x16, g_orig_w\n"
"  add x16, x16, :lo12:g_orig_w\n"
"  ldr x16, [x16]\n"
"  blr x16\n"
"  ldp x29, x30, [sp], #16\n"
"  ret\n"
".global shim_ws\n"
".type shim_ws, %function\n"
"shim_ws:\n"
"  stp x29, x30, [sp, #-16]!\n"
"  mov x29, sp\n"
"  bl hook_writeStr_impl\n"
"  ldp x29, x30, [sp], #16\n"
"  ret\n"
".global callws\n"
".type callws, %function\n"
"callws:\n"
"  stp x29, x30, [sp, #-16]!\n"
"  mov x29, sp\n"
"  adrp x16, g_orig_ws\n"
"  add x16, x16, :lo12:g_orig_ws\n"
"  ldr x16, [x16]\n"
"  blr x16\n"
"  ldp x29, x30, [sp], #16\n"
"  ret\n"
".global shim_r\n"
".type shim_r, %function\n"
"shim_r:\n"
"  stp x29, x30, [sp, #-16]!\n"
"  mov x29, sp\n"
"  bl hook_readStr_impl\n"
"  ldp x29, x30, [sp], #16\n"
"  ret\n"
".global callr\n"
".type callr, %function\n"
"callr:\n"
"  stp x29, x30, [sp, #-16]!\n"
"  mov x29, sp\n"
"  adrp x16, g_orig_r\n"
"  add x16, x16, :lo12:g_orig_r\n"
"  ldr x16, [x16]\n"
"  blr x16\n"
"  ldp x29, x30, [sp], #16\n"
"  ret\n"
);

extern "C" int hook_writeBA_impl(void *p, const unsigned char *buf, int len) {
    { char hx[3*32+1]; int n=0; for (int i=0;i<len && i<32 && buf;i++) n += snprintf(hx+n, sizeof(hx)-n, "%02x", buf[i]); hx[n]=0; LOGI("writeBA len=%d hex=%s", len, hx); }
    if (len == 32 && buf && g_on && g_seed_len > 0 &&
        (g_lastKey[0] == 0 || strcmp(g_lastKey, "deviceUniqueId") == 0)) {
        unsigned char tmp[32]; derive((uint32_t)getuid(), tmp, sizeof(tmp));
        LOGI("spoof parcel uid=%u key=[%s]", (unsigned)getuid(), g_lastKey);
        return ((int(*)(void*,const void*,long))callw)(p, tmp, len);
    }
    return ((int(*)(void*,const void*,long))callw)(p, buf, len);
}
extern "C" __attribute__((visibility("hidden"))) void *g_orig_ws = nullptr;
extern "C" void shim_ws(void);
extern "C" void callws(void*, const void*, long);
extern "C" int hook_writeStr_impl(void *p, const char *str, int len) {
    if (str) LOGI("writeStr len=%d [%s]", len, str);
    return ((int(*)(void*,const void*,long))callws)(p, str, len);
}

extern "C" int hook_readStr_impl(void *p, char **str, int *len) {
    int r = ((int(*)(void*,void*,void*))callr)(p, str, len);
    LOGI("readStr [%s]", (str && *str) ? *str : "");
    if (str && *str) { size_t n = strlen(*str); if (n < sizeof(g_lastKey)) { memcpy(g_lastKey, *str, n); g_lastKey[n] = 0; } }
    return r;
}

static bool unsafe_prologue(const uint32_t *w) {
    for (int i = 0; i < 4; i++) {
        uint32_t ins = w[i];
        if ((ins & 0x9F000000u) == 0x90000000u) return true;  /* adrp */
        if ((ins & 0x9F000000u) == 0x10000000u) return true;  /* adr  */
        if ((ins & 0x3B000000u) == 0x18000000u) return true;  /* ldr literal */
        if ((ins & 0x7C000000u) == 0x14000000u) return true;  /* b    */
    }
    return false;
}
static bool patch_one(void *target, void *hookfn, void **orig_out) {
    if (unsafe_prologue((const uint32_t*)target)) { LOGI("skip %p: unsafe prologue", target); return false; }
    LOGI("patching %p", target);
    uintptr_t page = (uintptr_t)target & ~(uintptr_t)0xFFF;
    if (mprotect((void*)page, 0x1000, PROT_READ|PROT_WRITE|PROT_EXEC) != 0) { LOGI("mprotect fail"); return false; }
    unsigned char saved[16]; memcpy(saved, target, 16);
    unsigned char *tr = (unsigned char*)mmap(nullptr, 0x1000, PROT_READ|PROT_WRITE|PROT_EXEC, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
    if (tr == MAP_FAILED) return false;
    memcpy(tr, saved, 16);
    uint32_t ldr = 0x58000050u, br = 0xD61F0200u;
    memcpy(tr+16, &ldr, 4); memcpy(tr+20, &br, 4);
    unsigned long back = (unsigned long)((uintptr_t)target + 16);
    memcpy(tr+24, &back, 8);
    *orig_out = tr;
    unsigned char code[16];
    memcpy(code, &ldr, 4); memcpy(code+4, &br, 4);
    unsigned long hv = (unsigned long)hookfn; memcpy(code+8, &hv, 8);
    memcpy(target, code, 16);
    __builtin___clear_cache((char*)page, (char*)page+0x1000);
    return true;
}

// ---- 挂载入口 ----
struct GotCtx { const char *sym; void *newfn; void **oldfn; int hits; };
static int got_cb(struct dl_phdr_info *info, size_t sz, void *data) {
    (void)sz; GotCtx *c = (GotCtx*)data;
    const char *name = info->dlpi_name ? info->dlpi_name : "";
    if (!strstr(name, "libbinder_ndk.so")) return 0;
    for (int i = 0; i < info->dlpi_phnum; i++) {
        const ElfW(Phdr) *ph = &info->dlpi_phdr[i];
        if (ph->p_type != PT_DYNAMIC) continue;
        ElfW(Dyn) *dyn = (ElfW(Dyn)*)(info->dlpi_addr + ph->p_vaddr);
        ElfW(Sym) *symtab = nullptr; const char *strtab = nullptr;
        ElfW(Rela) *jmprel = nullptr; size_t jmprelsz = 0;
        for (ElfW(Dyn) *d = dyn; d->d_tag != DT_NULL; d++) {
            if (d->d_tag == DT_SYMTAB) symtab = (ElfW(Sym)*)d->d_un.d_ptr;
            else if (d->d_tag == DT_STRTAB) strtab = (const char*)d->d_un.d_ptr;
            else if (d->d_tag == DT_JMPREL) jmprel = (ElfW(Rela)*)d->d_un.d_ptr;
            else if (d->d_tag == DT_PLTRELSZ) jmprelsz = d->d_un.d_val;
        }
        if (!symtab || !strtab || !jmprel) continue;
        size_t n = jmprelsz / sizeof(ElfW(Rela));
        for (size_t k = 0; k < n; k++) {
            ElfW(Rela) &r = jmprel[k];
            if (ELF64_R_TYPE(r.r_info) != R_AARCH64_JUMP_SLOT) continue;
            const char *sname = strtab + symtab[ELF64_R_SYM(r.r_info)].st_name;
            if (!strcmp(sname, c->sym)) {
                void **slot = (void**)(info->dlpi_addr + r.r_offset);
                if (*slot && !*c->oldfn) *c->oldfn = *slot;
                uintptr_t pg = (uintptr_t)slot & ~(uintptr_t)0xFFF;
                int mr = mprotect((void*)pg, 0x1000, PROT_READ|PROT_WRITE);
                if (mr != 0) { LOGI("mprotect fail sym=%s errno=%d", sname, errno); continue; }
                *slot = c->newfn;
                c->hits++;
                LOGI("patched %s slot=%p", sname, (void*)slot);
            }
        }
    }
    return 0;
}
// ---- 改 libbinder_ndk 的 GOT（TencDRM 方案）----
struct GotPatch { const char *sym; void *fn; void **orig; int hits; };
static int got_scan(struct dl_phdr_info *info, size_t, void *ud) {
    GotPatch *g = (GotPatch*)ud;
    const char *nm = info->dlpi_name ? info->dlpi_name : "(main)";
    if (strstr(nm, "linker64") || strstr(nm, "libc.so")) return 0;
    uintptr_t base = (uintptr_t)info->dlpi_addr;
    ElfW(Dyn) *dyn = nullptr;
    for (int i = 0; i < info->dlpi_phnum; i++)
        if (info->dlpi_phdr[i].p_type == PT_DYNAMIC)
            dyn = (ElfW(Dyn)*)(base + info->dlpi_phdr[i].p_vaddr);
    if (!dyn) return 0;
    auto fix = [&](ElfW(Addr) v)->uintptr_t {
        return (v && v < base) ? base + v : (uintptr_t)v;
    };
    ElfW(Sym) *syms = nullptr; const char *strs = nullptr;
    ElfW(Rela) *jmprel = nullptr; size_t jmpsz = 0;
    for (ElfW(Dyn) *d = dyn; d->d_tag != DT_NULL; d++) {
        switch (d->d_tag) {
            case DT_SYMTAB: syms = (ElfW(Sym)*)fix(d->d_un.d_ptr); break;
            case DT_STRTAB: strs = (const char*)fix(d->d_un.d_ptr); break;
            case DT_JMPREL: jmprel = (ElfW(Rela)*)fix(d->d_un.d_ptr); break;
            case DT_PLTRELSZ: jmpsz = d->d_un.d_val; break;
        }
    }
    if (!syms || !strs || !jmprel) { LOGI("got: missing tables"); return 0; }
    size_t n = jmpsz / sizeof(ElfW(Rela));
    for (size_t i = 0; i < n; i++) {
        ElfW(Rela) &r = jmprel[i];
        if (ELF64_R_TYPE(r.r_info) != R_AARCH64_JUMP_SLOT) continue;
        const char *sn = strs + syms[ELF64_R_SYM(r.r_info)].st_name;
        if (strcmp(sn, g->sym)) continue;
        void **slot = (void**)(base + r.r_offset);
        if (*g->orig == nullptr) *g->orig = *slot;
        uintptr_t pg = (uintptr_t)slot & ~(uintptr_t)0xFFF;
        if (mprotect((void*)pg, 0x1000, PROT_READ|PROT_WRITE) != 0) { LOGI("got mprotect fail"); continue; }
        *slot = g->fn;
        g->hits++;
        LOGI("got patched %s slot=%p orig=%p", g->sym, (void*)slot, *g->orig);
    }
    return 0;
}

static void arm_got(void) {
    GotPatch w = { "AParcel_writeByteArray", (void*)shim_w, &g_orig_w, 0 };
    GotPatch r = { "AParcel_readString", (void*)shim_r, &g_orig_r, 0 };
    dl_iterate_phdr(got_scan, &w);
    dl_iterate_phdr(got_scan, &r);
    if (!g_orig_w) g_orig_w = dlsym(RTLD_DEFAULT, "AParcel_writeByteArray");
    if (!g_orig_r) g_orig_r = dlsym(RTLD_DEFAULT, "AParcel_readString");
    g_ready = true;
    LOGI("armed: gotWriteBA=%d gotReadStr=%d orig=%p/%p", w.hits, r.hits, g_orig_w, g_orig_r);
}

__attribute__((constructor)) static void init(void) {
    char cb[256] = {0};
    int fd = open("/proc/self/cmdline", O_RDONLY);
    if (fd >= 0) { ssize_t r = read(fd, cb, sizeof(cb)-1); (void)r; close(fd); }
    if (!strstr(cb, "drm-service.widevine")) return;
    load_cfg();
    LOGI("entry pid=%d seed_len=%zu on=%d", (int)getpid(), g_seed_len, g_on?1:0);
    if (!g_on || g_seed_len == 0) { LOGI("disabled"); return; }
    arm_got();
}
