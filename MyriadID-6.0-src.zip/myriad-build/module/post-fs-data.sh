#!/system/bin/sh
MODDIR=${0%/*}
CFG="$MODDIR/config.prop"
[ -f "$CFG" ] || exit 0
S=$(grep -m1 '^seed=' "$CFG" | cut -d= -f2- | tr -d ' \r')
U=$(grep -m1 '^uids=' "$CFG" | cut -d= -f2- | tr -d ' \r')
E=$(grep -m1 '^enable=' "$CFG" | cut -d= -f2- | tr -d ' \r')
[ -n "$S" ] && /data/adb/ksud resetprop -n vendor.myriad.seed "$S" 2>/dev/null
[ -n "$U" ] && /data/adb/ksud resetprop -n vendor.myriad.uids "$U" 2>/dev/null
[ -n "$E" ] && /data/adb/ksud resetprop -n vendor.myriad.enable "$E" 2>/dev/null
exit 0
