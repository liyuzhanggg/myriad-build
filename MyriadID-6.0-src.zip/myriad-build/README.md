# 千面 MyriadID 6.0

按 App 伪造 Widevine DRMID 的 KernelSU/APatch/Magisk 模块（arm64）。

## 来源与许可

- 注入与 Parcel(GOT) 钩子核心：**TencDRM**（MIT License，作者 siri666666）
  https://github.com/siri666666/TencDRM
- 本项目在其基础上增加：**按调用方 uid 派生独立假 ID**、种子/白名单配置。
- 原始 LICENSE 见 `LICENSE` 文件，版权归原作者所有。

## 构建

```sh
make NDK=/path/to/android-ndk   # 产物在 out/
```

CI：见 `.github/workflows/build.yml`。

## 配置

`module/config.prop`：
```
seed=<32位hex>     # 主种子
uids=all           # 或 10333,10456
enable=1
```
