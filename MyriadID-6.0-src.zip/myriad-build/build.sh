#!/bin/sh
set -e
NDK="${ANDROID_NDK:-$ANDROID_NDK_ROOT}"
make NDK="$NDK"
cp -f out/libmyriad.so ./libmyriad.so
cp -f out/DRMID-inject ./DRMID-inject
ls -la libmyriad.so DRMID-inject
