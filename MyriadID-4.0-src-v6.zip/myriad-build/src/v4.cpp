#include <sys/mman.h>
#include <sys/system_properties.h>
#include <android/log.h>
#include <unistd.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <cstring>
#include <ctime>
#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>
#include <fstream>
#include <elfio/elfio.hpp>

#define TAG "MyriadV4"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
extern "C" __attribute__((visibility("hidden"))) void *g_orig_gpba_addr = nullptr;
extern "C" void dsh_hooked_gpba();
extern "C" void dsh_call_orig_gpba(void*, void*, const void*, void*);
extern "C" void gpba_helper(void*, void*, const std::string*, std::vector<uint8_t>*);

__asm__(
".text\n"
".global dsh_hooked_gpba\n"
".type dsh_hooked_gpba, %function\n"
"dsh_hooked_gpba:\n"
"  stp x29, x30, [sp, #-16]!\n"
"  mov x29, sp\n"
"  mov x3, x2\n  mov x2, x1\n  mov x1, x0\n  mov x0, x8\n"
"  bl gpba_helper\n"
"  ldp x29, x30, [sp], #16\n"
"  ret\n"
".global dsh_call_orig_gpba\n"
".type dsh_call_orig_gpba, %function\n"
"dsh_call_orig_gpba:\n"
"  stp x29, x30, [sp, #-16]!\n"
"  mov x29, sp\n"
"  mov x8, x0\n  mov x0, x1\n  mov x1, x2\n  mov x2, x3\n"
"  adrp x16, g_orig_gpba_addr\n"
"  add x16, x16, :lo12:g_orig_gpba_addr\n"
"  ldr x16, [x16]\n"
"  blr x16\n"
"  ldp x29, x30, [sp], #16\n"
"  ret\n"
);

// ---------- inline hook ----------
static bool patch(void *target, void *hookfn, void **orig_out) {
    uintptr_t page = (uintptr_t)target & ~0xFFFull;
    if (mprotect((void*)page, 0x2000, PROT_READ|PROT_WRITE|PROT_EXEC) != 0) { LOGI("mprotect fail"); return false; }
    unsigned char saved[16]; memcpy(saved, target, 16);
    unsigned char *tramp = (unsigned char*)mmap(nullptr, 64, PROT_READ|PROT_WRITE|PROT_EXEC, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
    if (tramp == MAP_FAILED) { LOGI("mmap tramp fail"); return false; }
    memcpy(tramp, saved, 16);
    uint32_t ldr = 0x58000050u;  // ldr x16, #8
    uint32_t br  = 0xD61F0200u;  // br x16
    memcpy(tramp + 16, &ldr, 4); memcpy(tramp + 20, &br, 4);
    unsigned long back = (unsigned long)((uintptr_t)target + 16);
    memcpy(tramp + 24, &back, 8);
    *orig_out = tramp;
    unsigned char patch[16];
    memcpy(patch, &ldr, 4); memcpy(patch + 4, &br, 4);
    unsigned long h = (unsigned long)hookfn; memcpy(patch + 8, &h, 8);
    memcpy(target, patch, 16);
    __builtin___clear_cache((char*)page, (char*)page + 0x2000);
    LOGI("hooked %p -> %p tramp=%p", target, hookfn, tramp);
    return true;
}

// ---------- 配置 ----------
static std::string g_seed_s; static unsigned char g_seed[64]; static size_t g_seed_len=0;
static bool g_on=true, g_all=false;
struct UidEnt { uint32_t uid; unsigned char salt; };
static std::vector<UidEnt> g_uids;
static int b64u(char c){ if(c>='A'&&c<='Z')return c-'A'; if(c>='a'&&c<='z')return c-'a'+26; if(c>='0'&&c<='9')return c-'0'+52; if(c=='-'||c=='+')return 62; if(c=='_'||c=='/')return 63; return -1; }
static bool decode_pack(const std::string &pack) {
    size_t start = 0; bool v2 = false;
    if (pack.rfind("v2:",0)==0) { start=3; v2=true; }
    else if (pack.rfind("v1:",0)==0) { start=3; }
    std::vector<unsigned char> buf; unsigned acc=0; int bits=0;
    for (size_t i=start;i<pack.size();++i){ char c=pack[i]; if(c=='=')continue; int v=b64u(c); if(v<0) return false; acc=(acc<<6)|(uint32_t)v; bits+=6; if(bits>=8){bits-=8; buf.push_back((unsigned char)((acc>>bits)&0xFF));} }
    size_t i=0; uint32_t prev=0; bool first=true;
    while (i<buf.size()) {
        uint32_t val=0; int shift=0;
        while (i<buf.size()) { unsigned char b=buf[i++]; val |= (uint32_t)(b&0x7f)<<shift; shift+=7; if(!(b&0x80)) break; }
        uint32_t uid = first ? val : prev + val; first=false; prev=uid;
        unsigned char salt=0; if (v2 && i<buf.size()) salt=buf[i++];
        g_uids.push_back({uid, salt});
    }
    return true;
}
static std::string prop(const char*k){char b[PROP_VALUE_MAX]={0};int n=__system_property_get(k,b);return n>0?std::string(b,n):std::string();}
static void load_cfg(){
    g_seed_len=0; g_uids.clear(); g_all=false;
    std::string s=prop("vendor.myriad.seed");
    for(size_t i=0;i+1<s.size()&&g_seed_len<64;i+=2){auto h=[](char c){if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;if(c>='A'&&c<='F')return c-'A'+10;return 0;};g_seed[g_seed_len++]=(unsigned char)((h(s[i])<<4)|h(s[i+1]));}
    g_on = prop("vendor.myriad.enable")!="0";
    std::string u=prop("vendor.myriad.uids");
    if(u=="all") g_all=true;
    else if(!u.empty()) {
        if(u.rfind("v1:",0)==0 || u.rfind("v2:",0)==0) { decode_pack(u); }
        else { size_t p=0; while(p<u.size()){size_t q=u.find(',',p); if(q==std::string::npos)q=u.size(); if(q>p) g_uids.push_back({(uint32_t)atoi(u.substr(p,q-p).c_str()),0}); p=q+1;} }
    }
}
static void derive(uint32_t uid,unsigned char salt,unsigned char*out,size_t ol){uint32_t h=2166136261u;for(size_t i=0;i<g_seed_len;i++){h^=g_seed[i];h*=16777619u;}for(int i=0;i<4;i++){h^=(uid>>(8*i))&0xFFu;h*=16777619u;} if(salt){h^=salt;h*=16777619u;}if(!h)h=0x9E3779B9u;for(size_t i=0;i<ol;i++){h^=h<<13;h^=h>>17;h^=h<<5;out[i]=(unsigned char)(h&0xFF);}}
static uint64_t g_cfg_ts = 0;
static void maybe_reload(void) {
    struct timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    uint64_t now = (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
    if (now - g_cfg_ts < 2000000000ull) return;   /* 2 秒节流 */
    g_cfg_ts = now;
    load_cfg();
}

static int uid_salt(uint32_t u, unsigned char *salt){ if(g_all){*salt=0;return 1;} for(auto &x:g_uids) if(x.uid==u){*salt=x.salt;return 1;} return 0; }

extern "C" void gpba_helper(void *sret, void *self, const std::string *name, std::vector<uint8_t> *out) {
    dsh_call_orig_gpba(sret, self, name, out);
    maybe_reload();
    if (name) { char nb[80]; size_t n=0; const unsigned char* raw=(const unsigned char*)name; for(; n<sizeof(nb)-1 && n<name->size() && raw[n]>=32 && raw[n]<127; ++n) nb[n]=raw[n]; nb[n]=0; LOGI("call name=%s uid=%u len=%zu", nb, (unsigned)getuid(), out?out->size():0); }
    if(!g_on||g_seed_len==0||!name||!out||out->empty()) return;
    if(name->size()!=14||memcmp(name->data(),"deviceUniqueId",14)!=0) return;
    uint32_t uid=(uint32_t)getuid();
    unsigned char salt=0;
    if(!uid_salt(uid,&salt)) return;
    { std::string hx; for (size_t i=0;i<out->size()&&i<64;i++){char b[4];snprintf(b,sizeof(b),"%02x",(*out)[i]);hx+=b;} LOGI("origid=%s", hx.c_str()); }
    unsigned char key[32]; derive(uid,salt,key,sizeof(key));
    for(size_t i=0;i<out->size();i++) (*out)[i]^=key[i%sizeof(key)];
    { std::string hx; for (size_t i=0;i<out->size()&&i<64;i++){char b[4];snprintf(b,sizeof(b),"%02x",(*out)[i]);hx+=b;} LOGI("spoofid=%s", hx.c_str()); }
    LOGI("spoofed uid=%u len=%zu", uid, out->size());
}

static std::string find_lib(const char *needle, uint64_t *base) {
    std::ifstream f("/proc/self/maps"); std::string line;
    while (std::getline(f, line)) {
        if (line.find(needle)==std::string::npos) continue;
        size_t dash=line.find('-'); if(dash==std::string::npos) continue;
        *base = strtoull(line.substr(0,dash).c_str(),nullptr,16);
        size_t sp=line.find('/'); if(sp==std::string::npos) continue;
        std::string path=line.substr(sp); if(path.find(".so")==std::string::npos) continue;
        return path;
    }
    return "";
}
static void *find_sym(const std::string &lib, uint64_t base, const char *needle) {
    ELFIO::elfio r; if(!r.load(lib)) return nullptr;
    for (auto &sec : r.sections) {
        if (sec->get_type()!=ELFIO::SHT_DYNSYM && sec->get_type()!=ELFIO::SHT_SYMTAB) continue;
        ELFIO::symbol_section_accessor a(r, sec.get());
        for (unsigned i=0;i<a.get_symbols_num();++i) {
            std::string n; ELFIO::Elf64_Addr v=0; ELFIO::Elf_Xword sz=0; unsigned char b=0,t=0,o=0; ELFIO::Elf_Half sh=0;
            a.get_symbol(i,n,v,sz,b,t,sh,o);
            if(v && n.find(needle)!=std::string::npos) return (void*)(base+v);
        }
    }
    return nullptr;
}
static bool hook_once() {
    static bool done=false; if(done) return true;
    static const char *names[]={"libwvaidl.so","libwvhidl.so","libwvdrm.so"};
    for (auto nm:names) {
        uint64_t base=0; std::string p=find_lib(nm,&base);
        if(p.empty()||!base) continue;
        void *sym=find_sym(p,base,"20getPropertyByteArrayE");
        if(!sym) continue;
        if(!patch(sym,(void*)dsh_hooked_gpba,&g_orig_gpba_addr)) return false;
        done=true; return true;
    }
    return false;
}
static void *retry(void*){ for(int i=0;i<600;i++){ usleep(100000); if(hook_once()){LOGI("late hook ok %dms",(i+1)*100);return nullptr;} } LOGI("give up"); return nullptr; }

extern "C" __attribute__((visibility("default"))) int myriad_init(void) {
    LOGI("myriad_init called pid=%d", (int)getpid());
    load_cfg();
    LOGI("cfg on=%d seed_len=%zu all=%d", g_on?1:0, g_seed_len, g_all?1:0);
    if (!g_on) return 1;
    if (hook_once()) { LOGI("hooked ok"); return 0; }
    LOGI("hooked fail");
    return 2;
}

__attribute__((constructor)) static void init(void) {
    LOGI("ctor pid=%d", (int)getpid());
    char cb[256] = {0};
    int fd = open("/proc/self/cmdline", O_RDONLY);
    if (fd >= 0) { ssize_t r = read(fd, cb, sizeof(cb)-1); (void)r; close(fd); }
    LOGI("cmdline=[%s]", cb);
    if (!strstr(cb, "drm-service.widevine")) { LOGI("not widevine, skip"); return; }
    load_cfg();
    if (!g_on) { LOGI("disabled"); return; }
    if (!hook_once()) { pthread_t t; pthread_create(&t,nullptr,retry,nullptr); pthread_detach(t); }
}
