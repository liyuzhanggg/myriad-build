#!/system/bin/sh
SKIPUNZIP=0
ui_print "- 千面 MyriadID 6.0 (基于 TencDRM, MIT)"
ui_print "- 仅支持 arm64"
