#!/bin/sh
set -e
NDK="${ANDROID_NDK:-$ANDROID_NDK_ROOT}"
CXX="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/clang++"
[ -x "$CXX" ] || { echo "no ndk clang++"; exit 1; }
$CXX --target=aarch64-linux-android24 -std=c++17 -Oz -fPIC -fno-exceptions -fno-rtti \
  -shared -o libmyriad.so src/v6.cpp -static-libstdc++ -llog -ldl
ls -la libmyriad.so
