#!/system/bin/sh
/data/adb/ksud resetprop -n vendor.myriad.enable 0 2>/dev/null
for p in $(ls /proc 2>/dev/null | grep -E '^[0-9]+$'); do
  e=$(readlink /proc/$p/exe 2>/dev/null) || continue
  case "$e" in */android.hardware.drm*widevine*) kill -9 "$p" 2>/dev/null;; esac
done
rm -f /data/local/tmp/myriad6.so /data/local/tmp/myriad6-inject 2>/dev/null
