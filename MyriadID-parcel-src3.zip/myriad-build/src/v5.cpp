// 千面 MyriadID · parcel 层伪装（参考 TencDRM 的公开实现思路）
#include <android/log.h>
#include <sys/system_properties.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <dlfcn.h>
#include <link.h>
#include <cstring>
#include <cstdint>
#include <cstdio>
#include <cerrno>
#include <csignal>
#include <csetjmp>
#include <unistd.h>
#include <string>
#include <vector>

#define TAG "MyriadV5"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

typedef int32_t binder_status_t;
typedef int32_t AParcel;
typedef binder_status_t (*writeBA_t)(AParcel*, const uint8_t*, int32_t);
typedef binder_status_t (*readStr_t)(const AParcel*, char**, int32_t*);

static writeBA_t g_orig_writeBA = nullptr;
static readStr_t g_orig_readStr = nullptr;

static unsigned char g_seed[64]; static size_t g_seed_len = 0;
static bool g_on = true; static bool g_ready = false;
static sigjmp_buf g_jmp;
static volatile int g_in_arm = 0;
static void segv_handler(int sig) { if (g_in_arm) { g_in_arm = 0; siglongjmp(g_jmp, sig); } }
static char g_lastKey[64] = {0};

static int hexv(char c){ if(c>='0'&&c<='9')return c-'0'; if(c>='a'&&c<='f')return c-'a'+10; if(c>='A'&&c<='F')return c-'A'+10; return 0; }
static void load_cfg(void) {
    char b[PROP_VALUE_MAX];
    g_seed_len = 0;
    if (__system_property_get("vendor.myriad.seed", b) > 0) {
        int n = (int)strlen(b); if (n > 128) n = 128;
        for (int i = 0; i + 1 < n && g_seed_len < 64; i += 2) g_seed[g_seed_len++] = (unsigned char)((hexv(b[i])<<4)|hexv(b[i+1]));
    }
    if (__system_property_get("vendor.myriad.enable", b) > 0 && b[0] == '0') g_on = false;
}
static void derive(uint32_t uid, unsigned char *out, size_t n) {
    uint32_t h = 2166136261u;
    for (size_t i = 0; i < g_seed_len; i++) { h ^= g_seed[i]; h *= 16777619u; }
    for (int i = 0; i < 4; i++) { h ^= (uid >> (8*i)) & 0xFFu; h *= 16777619u; }
    if (!h) h = 0x9E3779B9u;
    for (size_t i = 0; i < n; i++) { h ^= h << 13; h ^= h >> 17; h ^= h << 5; out[i] = (unsigned char)(h & 0xFF); }
}

// ---- 挂钩：AParcel_readString 记录属性名；writeByteArray 替换 32 字节 ID ----
static binder_status_t hook_readStr(const AParcel *p, char **str, int32_t *len) {
    binder_status_t r = g_orig_readStr ? g_orig_readStr(p, str, len) : -1;
    if (str && *str) {
        size_t n = strlen(*str);
        if (n < sizeof(g_lastKey)) { memcpy(g_lastKey, *str, n); g_lastKey[n] = 0; }
    }
    return r;
}
static binder_status_t hook_writeBA(AParcel *p, const uint8_t *buf, int32_t len) {
    if (len == 32 && buf && g_on && g_seed_len > 0 &&
        (strcmp(g_lastKey, "deviceUniqueId") == 0 || g_lastKey[0] == 0)) {
        unsigned char tmp[32];
        derive((uint32_t)getuid(), tmp, sizeof(tmp));
        LOGI("spoof parcel: key=[%s] uid=%u", g_lastKey, (unsigned)getuid());
        return g_orig_writeBA ? g_orig_writeBA(p, tmp, len) : -1;
    }
    return g_orig_writeBA ? g_orig_writeBA(p, buf, len) : -1;
}

// ---- 在 libbinder_ndk 的 GOT 中替换符号地址 ----
struct GotCtx { const char *sym; void *newfn; void **oldfn; int hits; };
static int got_cb(struct dl_phdr_info *info, size_t sz, void *data) {
    (void)sz; GotCtx *c = (GotCtx*)data;
    const char *name = info->dlpi_name ? info->dlpi_name : "";
    if (!strstr(name, "libbinder_ndk.so")) return 0;
    for (int i = 0; i < info->dlpi_phnum; i++) {
        const ElfW(Phdr) *ph = &info->dlpi_phdr[i];
        if (ph->p_type != PT_DYNAMIC) continue;
        ElfW(Dyn) *dyn = (ElfW(Dyn)*)(info->dlpi_addr + ph->p_vaddr);
        ElfW(Sym) *symtab = nullptr; const char *strtab = nullptr;
        ElfW(Rela) *jmprel = nullptr; size_t jmprelsz = 0;
        for (ElfW(Dyn) *d = dyn; d->d_tag != DT_NULL; d++) {
            if (d->d_tag == DT_SYMTAB) symtab = (ElfW(Sym)*)d->d_un.d_ptr;
            else if (d->d_tag == DT_STRTAB) strtab = (const char*)d->d_un.d_ptr;
            else if (d->d_tag == DT_JMPREL) jmprel = (ElfW(Rela)*)d->d_un.d_ptr;
            else if (d->d_tag == DT_PLTRELSZ) jmprelsz = d->d_un.d_val;
        }
        if (!symtab || !strtab || !jmprel) continue;
        size_t n = jmprelsz / sizeof(ElfW(Rela));
        for (size_t k = 0; k < n; k++) {
            ElfW(Rela) &r = jmprel[k];
            if (ELF64_R_TYPE(r.r_info) != R_AARCH64_JUMP_SLOT) continue;
            const char *sname = strtab + symtab[ELF64_R_SYM(r.r_info)].st_name;
            if (!strcmp(sname, c->sym)) {
                void **slot = (void**)(info->dlpi_addr + r.r_offset);
                if (*slot && !*c->oldfn) *c->oldfn = *slot;
                uintptr_t pg = (uintptr_t)slot & ~(uintptr_t)0xFFF;
                int mr = mprotect((void*)pg, 0x1000, PROT_READ|PROT_WRITE);
                if (mr != 0) { LOGI("mprotect fail sym=%s errno=%d", sname, errno); continue; }
                *slot = c->newfn;
                c->hits++;
                LOGI("patched %s slot=%p", sname, (void*)slot);
            }
        }
    }
    return 0;
}
static void arm_got(void) {
    GotCtx a = { "AParcel_writeByteArray", (void*)hook_writeBA, (void**)&g_orig_writeBA, 0 };
    GotCtx b = { "AParcel_readString", (void*)hook_readStr, (void**)&g_orig_readStr, 0 };
    struct sigaction sa{}; sa.sa_handler = segv_handler; sigemptyset(&sa.sa_mask); sa.sa_flags = SA_NODEFER;
    struct sigaction old1{}, old2{};
    sigaction(SIGSEGV, &sa, &old1); sigaction(SIGBUS, &sa, &old2);
    int jv = sigsetjmp(g_jmp, 1);
    if (jv == 0) {
        g_in_arm = 1;
        LOGI("stub: scanning libbinder_ndk GOT");
        dl_iterate_phdr(got_cb, &a);
        LOGI("stub: writeBA done hits=%d", a.hits);
        dl_iterate_phdr(got_cb, &b);
        LOGI("stub: readStr done hits=%d", b.hits);
        g_in_arm = 0;
    } else {
        LOGI("arm aborted by signal %d", jv);
    }
    sigaction(SIGSEGV, &old1, nullptr); sigaction(SIGBUS, &old2, nullptr);
    if (!g_orig_writeBA) g_orig_writeBA = (writeBA_t)dlsym(RTLD_DEFAULT, "AParcel_writeByteArray");
    if (!g_orig_readStr) g_orig_readStr = (readStr_t)dlsym(RTLD_DEFAULT, "AParcel_readString");
    g_ready = true;
    LOGI("armed: writeBA=%d readStr=%d orig=%p/%p", a.hits, b.hits, (void*)g_orig_writeBA, (void*)g_orig_readStr);
}

__attribute__((constructor)) static void init(void) {
    char cb[256] = {0};
    int fd = open("/proc/self/cmdline", O_RDONLY);
    if (fd >= 0) { ssize_t r = read(fd, cb, sizeof(cb)-1); (void)r; close(fd); }
    if (!strstr(cb, "drm-service.widevine")) return;
    load_cfg();
    LOGI("entry pid=%d seed_len=%zu on=%d", (int)getpid(), g_seed_len, g_on?1:0);
    if (!g_on || g_seed_len == 0) { LOGI("disabled"); return; }
    arm_got();
}
