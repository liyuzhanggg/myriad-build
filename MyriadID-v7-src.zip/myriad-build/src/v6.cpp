// 千面 MyriadID · Parcel(GOT) 层 · 干净重写
#include <android/log.h>
#include <sys/system_properties.h>
#include <sys/mman.h>
#include <link.h>
#include <dlfcn.h>
#include <unistd.h>
#include <fcntl.h>
#include <cstring>
#include <cstdio>
#include <cstdint>

#define TAG "MyriadV6"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

typedef int32_t AParcel;
static int (*g_orig_writeBA)(AParcel*, const uint8_t*, int32_t) = nullptr;
static int (*g_orig_readStr)(const AParcel*, char**, int32_t*) = nullptr;
static unsigned char g_seed[64];
static size_t g_seed_len = 0;
static bool g_on = true, g_spoof = true;
static char g_key[64] = {0};

static int hexv(char c){ if(c>='0'&&c<='9')return c-'0'; if(c>='a'&&c<='f')return c-'a'+10; if(c>='A'&&c<='F')return c-'A'+10; return 0; }
static void load_cfg(void) {
    char b[PROP_VALUE_MAX]; g_seed_len = 0;
    if (__system_property_get("vendor.myriad.seed", b) > 0) {
        int n = (int)strlen(b); if (n > 128) n = 128;
        for (int i = 0; i + 1 < n && g_seed_len < 64; i += 2) g_seed[g_seed_len++] = (unsigned char)((hexv(b[i])<<4)|hexv(b[i+1]));
    }
    if (__system_property_get("vendor.myriad.enable", b) > 0 && b[0] == '0') g_on = false;
    if (__system_property_get("vendor.myriad.spoof", b) > 0 && b[0] == '0') g_spoof = false;
}
static void derive(uint32_t uid, unsigned char *out, size_t n) {
    uint32_t h = 2166136261u;
    for (size_t i = 0; i < g_seed_len; i++) { h ^= g_seed[i]; h *= 16777619u; }
    for (int i = 0; i < 4; i++) { h ^= (uid >> (8*i)) & 0xFFu; h *= 16777619u; }
    if (!h) h = 0x9E3779B9u;
    for (size_t i = 0; i < n; i++) { h ^= h << 13; h ^= h >> 17; h ^= h << 5; out[i] = (unsigned char)(h & 0xFF); }
}
static void log_hex(const uint8_t *b, int len) {
    char hx[3*48+1]; int n = 0;
    for (int i = 0; i < len && i < 48 && b; i++) n += snprintf(hx+n, sizeof(hx)-n, "%02x", b[i]);
    hx[n] = 0; LOGI("writeBA len=%d hex=%s", len, hx);
}

static int hook_writeBA(AParcel *p, const uint8_t *buf, int32_t len) {
    log_hex(buf, len);
    if (g_spoof && g_on && g_seed_len > 0 && len == 32 && buf) {
        unsigned char tmp[32];
        derive((uint32_t)getuid(), tmp, sizeof(tmp));
        LOGI("spoof parcel key=[%s] uid=%u", g_key, (unsigned)getuid());
        return g_orig_writeBA ? g_orig_writeBA(p, tmp, 32) : -1;
    }
    return g_orig_writeBA ? g_orig_writeBA(p, buf, len) : -1;
}
static int hook_readStr(const AParcel *p, char **str, int32_t *len) {
    int r = g_orig_readStr ? g_orig_readStr(p, str, len) : -1;
    if (str && *str) { size_t n = strlen(*str); if (n < sizeof(g_key)) { memcpy(g_key, *str, n); g_key[n] = 0; } }
    return r;
}

struct GotCtx { const char *sym; void *fn; void **orig; int hits; };
static int got_scan(struct dl_phdr_info *info, size_t, void *ud) {
    GotCtx *g = (GotCtx*)ud;
    const char *nm = info->dlpi_name ? info->dlpi_name : "";
    if (strstr(nm, "linker") || strstr(nm, "libc.so")) return 0;
    uintptr_t base = (uintptr_t)info->dlpi_addr;
    if (!base) return 0;
    ElfW(Dyn) *dyn = nullptr;
    for (int i = 0; i < info->dlpi_phnum; i++)
        if (info->dlpi_phdr[i].p_type == PT_DYNAMIC)
            dyn = (ElfW(Dyn)*)(base + info->dlpi_phdr[i].p_vaddr);
    if (!dyn) return 0;
    ElfW(Sym) *syms = nullptr; const char *strs = nullptr;
    ElfW(Rela) *jmprel = nullptr; size_t jmpsz = 0;
    for (ElfW(Dyn) *d = dyn; d->d_tag != DT_NULL; d++) {
        uintptr_t v = (uintptr_t)d->d_un.d_ptr;
        if (d->d_tag == DT_SYMTAB) syms = (ElfW(Sym)*)(v < base ? base + v : v);
        else if (d->d_tag == DT_STRTAB) strs = (const char*)(v < base ? base + v : v);
        else if (d->d_tag == DT_JMPREL) jmprel = (ElfW(Rela)*)(v < base ? base + v : v);
        else if (d->d_tag == DT_PLTRELSZ) jmpsz = d->d_un.d_val;
    }
    if (!syms || !strs || !jmprel || !jmpsz) return 0;
    size_t n = jmpsz / sizeof(ElfW(Rela));
    for (size_t i = 0; i < n; i++) {
        ElfW(Rela) &r = jmprel[i];
        if (ELF64_R_TYPE(r.r_info) != R_AARCH64_JUMP_SLOT) continue;
        ElfW(Sym) &sym = syms[ELF64_R_SYM(r.r_info)];
        const char *sn = strs + sym.st_name;
        if (strcmp(sn, g->sym)) continue;
        if (sym.st_shndx != SHN_UNDEF) continue;              /* 必须是外部引用 */
        if (ELF64_ST_TYPE(sym.st_info) != STT_FUNC) continue;  /* 必须是函数 */
        void **slot = (void**)(base + r.r_offset);
        LOGI("slot[%s] before=%p in=%s", sn, (void*)*slot, nm);
        if (!g->orig || *g->orig == nullptr) *g->orig = *slot;
        uintptr_t pg = (uintptr_t)slot & ~(uintptr_t)0xFFF;
        if (mprotect((void*)pg, 0x1000, PROT_READ|PROT_WRITE) != 0) continue;
        *slot = g->fn;
        g->hits++;
        LOGI("got patched %s slot=%p", g->sym, (void*)slot);
    }
    return 0;
}

static void arm(void) {
    GotCtx w = { "AParcel_writeByteArray", (void*)hook_writeBA, (void**)&g_orig_writeBA, 0 };
    GotCtx r = { "AParcel_readString", (void*)hook_readStr, (void**)&g_orig_readStr, 0 };
    dl_iterate_phdr(got_scan, &w);
    dl_iterate_phdr(got_scan, &r);
    if (!g_orig_writeBA) g_orig_writeBA = (decltype(g_orig_writeBA))dlsym(RTLD_DEFAULT, "AParcel_writeByteArray");
    if (!g_orig_readStr) g_orig_readStr = (decltype(g_orig_readStr))dlsym(RTLD_DEFAULT, "AParcel_readString");
    LOGI("armed writeBA=%d readStr=%d spoof=%d", w.hits, r.hits, g_spoof ? 1 : 0);
}

__attribute__((constructor)) static void init(void) {
    char cb[256] = {0};
    int fd = open("/proc/self/cmdline", O_RDONLY);
    if (fd >= 0) { ssize_t r = read(fd, cb, sizeof(cb)-1); (void)r; close(fd); }
    if (!strstr(cb, "drm-service.widevine")) return;
    load_cfg();
    LOGI("entry pid=%d seed_len=%zu", (int)getpid(), g_seed_len);
    if (!g_on || g_seed_len == 0) return;
    arm();
}
