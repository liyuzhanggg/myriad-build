#!/system/bin/sh
# 千面 MyriadID 6.0 · service（基于 TencDRM 的注入逻辑, MIT）
MODDIR=${0%/*}
CFG="$MODDIR/config.prop"
LIB=/data/local/tmp/myriad6.so
INJ=/data/local/tmp/myriad6-inject

getcfg() { grep -m1 "^$1=" "$CFG" 2>/dev/null | cut -d= -f2- | tr -d ' \r'; }

cp "$MODDIR/prebuilt/myriad6-inject" "$INJ" 2>/dev/null; chmod 755 "$INJ" 2>/dev/null
cp "$MODDIR/prebuilt/libmyriad.so" "$LIB" 2>/dev/null;  chmod 755 "$LIB" 2>/dev/null
chcon u:object_r:shell_data_file:s0 "$LIB" "$INJ" 2>/dev/null

while true; do
  SEED=$(getcfg seed); UIDS=$(getcfg uids); EN=$(getcfg enable)
  [ -n "$SEED" ] && /data/adb/ksud resetprop -n vendor.myriad.seed "$SEED" 2>/dev/null
  [ -n "$UIDS" ] && /data/adb/ksud resetprop -n vendor.myriad.uids "$UIDS" 2>/dev/null
  [ -n "$EN" ]   && /data/adb/ksud resetprop -n vendor.myriad.enable "$EN" 2>/dev/null

  for p in $(ls /proc 2>/dev/null | grep -E '^[0-9]+$'); do
    e=$(readlink /proc/$p/exe 2>/dev/null) || continue
    case "$e" in
      */android.hardware.drm*widevine*|*/mediadrmserver)
        grep -q "myriad6" /proc/$p/maps 2>/dev/null && continue
        "$INJ" "$p" "$LIB" >/dev/null 2>&1
        grep -q "myriad6" /proc/$p/maps 2>/dev/null && /data/adb/ksud resetprop -n vendor.myriad.injected ok 2>/dev/null
        ;;
    esac
  done
  sleep 5
done
